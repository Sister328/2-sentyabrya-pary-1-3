# Python — задания 1–9

Практическая работа от 9 сентября 2026 года.

Файл `main.py` содержит решения всех 9 заданий:
1. Goods
2. TravelBlog
3. MediaPlayer
4. Money
5. Point
6. DataBase
7. Graph
8. CPU, Memory, MotherBoard
9. Figure, Line, Rect, Ellipse, Triangle

Запуск:
```bash
python3 main.py
```
