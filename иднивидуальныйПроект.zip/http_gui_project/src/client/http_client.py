import socket, ssl
from ..http.models import Url, Request, HttpError
from ..http.codec import serialize_request, read_response
from ..net.socket_wrapper import SocketWrapper
from ..net.interfaces import IHttpClient

class HttpClient(IHttpClient):
    def __init__(self, timeout_ms=5000): self.timeout_ms = timeout_ms
    def set_timeout(self, ms):
        if ms <= 0: raise ValueError("Таймаут должен быть больше нуля.")
        self.timeout_ms = ms
    def _send(self, url, method, body=b"", content_type=None, headers=None):
        target = Url.parse(url); headers = dict(headers or {})
        if content_type and not any(k.lower() == "content-type" for k in headers): headers["Content-Type"] = content_type
        if not any(k.lower() == "user-agent" for k in headers): headers["User-Agent"] = "LevelUpHTTP/1.0"
        req = Request(method, target.path, headers=headers, body=body)
        raw = socket.create_connection((target.host, target.port), timeout=self.timeout_ms / 1000)
        try:
            raw.settimeout(self.timeout_ms / 1000)
            if target.scheme == "https": raw = ssl.create_default_context().wrap_socket(raw, server_hostname=target.host)
            with SocketWrapper(raw) as sock:
                sock.send_all(serialize_request(req))
                response = read_response(sock)
            return response
        except socket.timeout as exc: raise TimeoutError(f"Превышен таймаут {self.timeout_ms} мс.") from exc
        except (ConnectionRefusedError, socket.gaierror, OSError) as exc: raise ConnectionError(f"Не удалось подключиться: {exc}") from exc
    def get(self, url, headers=None): return self._send(url, "GET", headers=headers)
    def post(self, url, body, content_type="text/plain", headers=None):
        if isinstance(body, str): body = body.encode("utf-8")
        return self._send(url, "POST", body, content_type, headers)
