import json, logging, queue, threading, tkinter as tk, webbrowser
from tkinter import ttk, messagebox
from ..client.http_client import HttpClient
from ..http.models import ParseError
from ..server.http_server import HttpServer
from ..server.router import build_router

class HttpGuiApp:
    def __init__(self, root):
        self.root = root; self.root.title("HTTP Lab — клиент и сервер"); self.root.geometry("1000x720"); self.root.minsize(800, 580)
        self.client = HttpClient(); self.events = queue.Queue(); self.server = HttpServer(build_router(), self._queue_log)
        self._configure_style(); self._build_ui(); self.root.after(100, self._poll); self.root.protocol("WM_DELETE_WINDOW", self._close)
    def _configure_style(self):
        style = ttk.Style();
        try: style.theme_use("clam")
        except tk.TclError: pass
        style.configure("TNotebook.Tab", padding=(16, 8)); style.configure("Title.TLabel", font=("TkDefaultFont", 16, "bold")); style.configure("Status.TLabel", font=("TkDefaultFont", 10, "bold"))
    def _build_ui(self):
        outer = ttk.Frame(self.root, padding=14); outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="HTTP LAB", style="Title.TLabel").pack(anchor="w")
        ttk.Label(outer, text="Учебный HTTP-клиент и сервер на сокетах Python").pack(anchor="w", pady=(0, 10))
        self.tabs = ttk.Notebook(outer); self.tabs.pack(fill="both", expand=True)
        self.client_tab = ttk.Frame(self.tabs, padding=12); self.server_tab = ttk.Frame(self.tabs, padding=12)
        self.tabs.add(self.client_tab, text="Клиент"); self.tabs.add(self.server_tab, text="Сервер")
        self._build_client(); self._build_server()
    def _build_client(self):
        f = self.client_tab; f.columnconfigure(1, weight=1); f.rowconfigure(5, weight=1); f.rowconfigure(8, weight=2)
        ttk.Label(f, text="URL").grid(row=0,column=0,sticky="w",padx=(0,8),pady=4)
        self.url = tk.StringVar(value="http://127.0.0.1:8080/"); ttk.Entry(f,textvariable=self.url).grid(row=0,column=1,sticky="ew",pady=4)
        self.method = tk.StringVar(value="GET"); ttk.Label(f,text="Метод").grid(row=1,column=0,sticky="w",padx=(0,8),pady=4)
        methodbox=ttk.Combobox(f,textvariable=self.method,values=("GET","POST"),state="readonly",width=10); methodbox.grid(row=1,column=1,sticky="w",pady=4); methodbox.bind("<<ComboboxSelected>>",lambda e:self._toggle_body())
        ttk.Label(f,text="Заголовки (имя: значение, по одному на строку)").grid(row=2,column=0,columnspan=2,sticky="w",pady=(8,2))
        self.headers=tk.Text(f,height=4,wrap="none"); self.headers.grid(row=3,column=0,columnspan=2,sticky="ew"); self.headers.insert("1.0","Accept: */*")
        ttk.Label(f,text="Тело запроса").grid(row=4,column=0,columnspan=2,sticky="w",pady=(8,2))
        self.body=tk.Text(f,height=5,wrap="word"); self.body.grid(row=5,column=0,columnspan=2,sticky="nsew")
        actions=ttk.Frame(f); actions.grid(row=6,column=0,columnspan=2,sticky="ew",pady=8)
        self.send_btn=ttk.Button(actions,text="Отправить запрос",command=self._send); self.send_btn.pack(side="left")
        ttk.Button(actions,text="Очистить",command=self._clear_client).pack(side="left",padx=8)
        self.loading=ttk.Label(actions,text=""); self.loading.pack(side="left",padx=10)
        self.response_status=ttk.Label(f,text="Ответ ещё не получен",style="Status.TLabel"); self.response_status.grid(row=7,column=0,columnspan=2,sticky="w",pady=(4,2))
        ttk.Label(f,text="Ответ (заголовки и тело)").grid(row=8,column=0,columnspan=2,sticky="nw")
        self.response=tk.Text(f,wrap="word",state="disabled"); self.response.grid(row=9,column=0,columnspan=2,sticky="nsew"); f.rowconfigure(9,weight=2)
        self._toggle_body()
    def _toggle_body(self): self.body.configure(state="normal" if self.method.get()=="POST" else "disabled")
    def _send(self):
        try:
            url=self.url.get().strip()
            if not url: raise ParseError("Введите URL.")
            headers={}
            for line in self.headers.get("1.0","end").splitlines():
                if not line.strip(): continue
                if ":" not in line: raise ParseError(f"Некорректный заголовок: {line}")
                k,v=line.split(":",1); k=k.strip(); v=v.strip()
                if not k or "\r" in v or "\n" in v: raise ParseError("Некорректное имя или значение заголовка.")
                headers[k]=v
        except Exception as exc: self._show_error(str(exc)); return
        method=self.method.get(); body=self.body.get("1.0","end-1c")
        self.send_btn.configure(state="disabled"); self.loading.configure(text="Отправка…")
        def work():
            try:
                result=self.client.get(url,headers) if method=="GET" else self.client.post(url,body,headers=headers)
                self.events.put(("client_ok",result))
            except Exception as exc: self.events.put(("client_error",str(exc)))
        threading.Thread(target=work,daemon=True).start()
    def _show_error(self,msg):
        self.response_status.configure(text="Ошибка запроса",foreground="#b42318"); self.response.configure(state="normal"); self.response.delete("1.0","end"); self.response.insert("1.0",msg); self.response.configure(state="disabled")
    def _clear_client(self):
        self.url.set(""); self.headers.delete("1.0","end"); self.body.configure(state="normal"); self.body.delete("1.0","end"); self._toggle_body(); self.response.configure(state="normal"); self.response.delete("1.0","end"); self.response.configure(state="disabled"); self.response_status.configure(text="Ответ ещё не получен")
    def _build_server(self):
        f=self.server_tab; f.columnconfigure(0,weight=1); f.rowconfigure(3,weight=1)
        top=ttk.Frame(f); top.grid(row=0,column=0,sticky="ew",pady=(0,10)); ttk.Label(top,text="Порт:").pack(side="left")
        self.port=tk.StringVar(value="8080"); ttk.Entry(top,textvariable=self.port,width=9).pack(side="left",padx=6)
        self.start_btn=ttk.Button(top,text="Запустить",command=self._start_server); self.start_btn.pack(side="left",padx=4)
        self.stop_btn=ttk.Button(top,text="Остановить",command=self._stop_server,state="disabled"); self.stop_btn.pack(side="left",padx=4)
        self.open_btn=ttk.Button(top,text="Открыть в браузере",command=self._open_browser); self.open_btn.pack(side="left",padx=4)
        self.server_state=ttk.Label(f,text="● Сервер остановлен",foreground="#b42318",style="Status.TLabel"); self.server_state.grid(row=1,column=0,sticky="w",pady=(0,8))
        cols=("time","method","path","status","ms"); self.logtree=ttk.Treeview(f,columns=cols,show="headings",height=15)
        for col,title,width in (("time","Время",100),("method","Метод",90),("path","Путь",360),("status","Статус",90),("ms","мс",100)):
            self.logtree.heading(col,text=title); self.logtree.column(col,width=width,anchor="w")
        self.logtree.grid(row=2,column=0,sticky="nsew"); f.rowconfigure(2,weight=1)
        bottom=ttk.Frame(f); bottom.grid(row=3,column=0,sticky="ew",pady=8); ttk.Button(bottom,text="Очистить лог",command=lambda:self.logtree.delete(*self.logtree.get_children())).pack(side="left")
        ttk.Label(f,text="Маршруты: GET / · POST /echo · GET /time · GET /headers · GET /status/{code}").grid(row=4,column=0,sticky="w",pady=6)
    def _start_server(self):
        try:
            port=int(self.port.get()); self.server.start(port=port)
            self.server_state.configure(text=f"● Сервер запущен на 127.0.0.1:{port}",foreground="#067647"); self.start_btn.configure(state="disabled"); self.stop_btn.configure(state="normal")
        except Exception as exc: messagebox.showerror("Не удалось запустить сервер",str(exc))
    def _stop_server(self):
        self.server.stop(); self.server_state.configure(text="● Сервер остановлен",foreground="#b42318"); self.start_btn.configure(state="normal"); self.stop_btn.configure(state="disabled")
    def _open_browser(self): webbrowser.open(f"http://127.0.0.1:{int(self.port.get() or 8080)}/")
    def _queue_log(self,item): self.events.put(("server_log",item))
    def _poll(self):
        try:
            while True:
                kind,data=self.events.get_nowait()
                if kind=="client_ok":
                    self.send_btn.configure(state="normal"); self.loading.configure(text="")
                    self.response_status.configure(text=f"HTTP {data.status} {data.reason}",foreground="#067647" if data.status<400 else "#b54708")
                    text="ЗАГОЛОВКИ ОТВЕТА\n"+"\n".join(f"{k}: {v}" for k,v in data.headers.items())+"\n\nТЕЛО ОТВЕТА\n"
                    try: text+=data.body.decode("utf-8")
                    except UnicodeDecodeError: text+=repr(data.body)
                    self.response.configure(state="normal"); self.response.delete("1.0","end"); self.response.insert("1.0",text); self.response.configure(state="disabled")
                elif kind=="client_error": self.send_btn.configure(state="normal"); self.loading.configure(text=""); self._show_error(data)
                elif kind=="server_log": self.logtree.insert("","end",values=(data["time"],data["method"],data["path"],data["status"],data["ms"])); self.logtree.yview_moveto(1)
        except queue.Empty: pass
        self.root.after(100,self._poll)
    def _close(self): self.server.stop(); self.root.destroy()

def main():
    logging.basicConfig(filename="logs/http_gui.log",level=logging.INFO,format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    root=tk.Tk(); HttpGuiApp(root); root.mainloop()
