"""Bounded HTTP/1.x parsing and serialization for the educational project."""
import email.utils
import json
import re
from datetime import datetime, timezone
from typing import Dict, Tuple
from .models import ParseError, Request, Response

MAX_HEADER_BYTES = 8192
MAX_BODY_BYTES = 8 * 1024 * 1024
REASONS = {200: "OK", 201: "Created", 204: "No Content", 301: "Moved Permanently", 302: "Found", 400: "Bad Request", 404: "Not Found", 405: "Method Not Allowed", 418: "I'm a teapot", 500: "Internal Server Error"}


def _header_map(lines) -> Dict[str, str]:
    result = {}
    for line in lines:
        if not line:
            continue
        if line[:1] in " \t" or ":" not in line:
            raise ParseError("Некорректный HTTP-заголовок.")
        name, value = line.split(":", 1)
        name = name.strip()
        if not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", name):
            raise ParseError("Недопустимое имя HTTP-заголовка.")
        result[name] = value.strip()
    return result


def parse_request(data: bytes) -> Request:
    if len(data) > MAX_HEADER_BYTES + MAX_BODY_BYTES:
        raise ParseError("HTTP-запрос превышает допустимый размер.")
    head, sep, body = data.partition(b"\r\n\r\n")
    if not sep or len(head) > MAX_HEADER_BYTES:
        raise ParseError("Заголовки отсутствуют, неполны или слишком велики.")
    try:
        lines = head.decode("iso-8859-1").split("\r\n")
        method, path, version = lines[0].split(" ", 2)
    except (UnicodeDecodeError, ValueError, IndexError) as exc:
        raise ParseError("Некорректная стартовая строка HTTP.") from exc
    if not re.fullmatch(r"[A-Z]{1,16}", method) or not path.startswith("/") or version not in ("HTTP/1.0", "HTTP/1.1"):
        raise ParseError("Некорректная стартовая строка HTTP.")
    headers = _header_map(lines[1:])
    if version == "HTTP/1.1" and not any(k.lower() == "host" for k in headers):
        raise ParseError("Для HTTP/1.1 обязателен заголовок Host.")
    length = next((v for k, v in headers.items() if k.lower() == "content-length"), "0")
    try:
        size = int(length)
    except ValueError as exc:
        raise ParseError("Некорректный Content-Length.") from exc
    if size < 0 or size > MAX_BODY_BYTES:
        raise ParseError("Недопустимый размер тела запроса.")
    if len(body) < size:
        raise ParseError("Тело запроса неполное.")
    return Request(method.upper(), path, version, headers, body[:size])


def serialize_request(req: Request) -> bytes:
    headers = dict(req.headers)
    if not any(k.lower() == "host" for k in headers):
        headers["Host"] = "localhost"
    if req.body and not any(k.lower() == "content-length" for k in headers):
        headers["Content-Length"] = str(len(req.body))
    if not any(k.lower() == "connection" for k in headers):
        headers["Connection"] = "close"
    first = f"{req.method.upper()} {req.path} {req.version}\r\n"
    return (first + "".join(f"{k}: {v}\r\n" for k, v in headers.items()) + "\r\n").encode("iso-8859-1") + req.body


def serialize_response(resp: Response) -> bytes:
    headers = dict(resp.headers)
    headers.setdefault("Date", email.utils.format_datetime(datetime.now(timezone.utc), usegmt=True))
    headers.setdefault("Content-Length", str(len(resp.body)))
    headers.setdefault("Connection", "close")
    reason = resp.reason or REASONS.get(resp.status, "Unknown")
    first = f"{resp.version} {resp.status} {reason}\r\n"
    return (first + "".join(f"{k}: {v}\r\n" for k, v in headers.items()) + "\r\n").encode("iso-8859-1") + resp.body


def read_response(sock) -> Response:
    data = bytearray()
    while b"\r\n\r\n" not in data:
        chunk = sock.recv(4096)
        if not chunk:
            raise ParseError("Соединение закрыто до получения заголовков.")
        data.extend(chunk)
        if len(data) > MAX_HEADER_BYTES:
            raise ParseError("Заголовки ответа слишком велики.")
    head, _, body = bytes(data).partition(b"\r\n\r\n")
    try:
        lines = head.decode("iso-8859-1").split("\r\n")
        version, status, *reason = lines[0].split(" ")
        headers = _header_map(lines[1:])
        status = int(status)
    except (ValueError, IndexError) as exc:
        raise ParseError("Некорректный HTTP-ответ.") from exc
    low = {k.lower(): v for k, v in headers.items()}
    if low.get("transfer-encoding", "").lower() == "chunked":
        body = _read_chunked(sock, body)
    else:
        try:
            length = int(low.get("content-length", len(body)))
        except ValueError as exc:
            raise ParseError("Некорректный Content-Length в ответе.") from exc
        if length < 0 or length > MAX_BODY_BYTES:
            raise ParseError("Недопустимый размер тела ответа.")
        while len(body) < length:
            chunk = sock.recv(min(4096, length - len(body)))
            if not chunk:
                raise ParseError("Тело ответа неполное.")
            body += chunk
        body = body[:length]
    return Response(status, " ".join(reason), version, headers, body)


def _read_chunked(sock, initial: bytes) -> bytes:
    data = bytearray(initial)
    out = bytearray()
    while True:
        while b"\r\n" not in data:
            chunk = sock.recv(4096)
            if not chunk: raise ParseError("Неполный chunked-ответ.")
            data.extend(chunk)
        line, _, rest = data.partition(b"\r\n")
        try: size = int(line.split(b";", 1)[0], 16)
        except ValueError as exc: raise ParseError("Некорректный размер chunk.") from exc
        data = bytearray(rest)
        if size == 0:
            while b"\r\n\r\n" not in data and data[-2:] != b"\r\n":
                chunk = sock.recv(4096)
                if not chunk: break
                data.extend(chunk)
            return bytes(out)
        while len(data) < size + 2:
            chunk = sock.recv(4096)
            if not chunk: raise ParseError("Неполный chunked-ответ.")
            data.extend(chunk)
        out.extend(data[:size])
        data = data[size + 2:]
        if len(out) > MAX_BODY_BYTES: raise ParseError("Chunked-тело слишком велико.")
