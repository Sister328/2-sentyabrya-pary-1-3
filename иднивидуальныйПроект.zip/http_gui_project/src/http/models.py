"""HTTP data models and URL parsing."""
from dataclasses import dataclass, field
from typing import Dict
from urllib.parse import urlsplit


class ParseError(ValueError):
    """Raised when URL or HTTP data cannot be parsed safely."""


class HttpError(Exception):
    def __init__(self, status: int, reason: str, body: bytes = b""):
        self.status, self.reason, self.body = status, reason, body
        super().__init__(f"HTTP {status} {reason}".strip())


@dataclass(frozen=True)
class Url:
    scheme: str
    host: str
    port: int
    path: str

    @classmethod
    def parse(cls, value: str) -> "Url":
        if not isinstance(value, str) or not value.strip():
            raise ParseError("Введите URL.")
        try:
            parts = urlsplit(value.strip())
            scheme = parts.scheme.lower()
            if scheme not in ("http", "https"):
                raise ParseError("Поддерживаются только http:// и https://")
            if not parts.hostname:
                raise ParseError("В URL не указан хост.")
            port = parts.port or (443 if scheme == "https" else 80)
            if not 1 <= port <= 65535:
                raise ParseError("Порт должен быть в диапазоне 1–65535.")
            path = parts.path or "/"
            if parts.query:
                path += "?" + parts.query
            if parts.fragment:
                # Фрагмент URL не передаётся HTTP-серверу.
                pass
            return cls(scheme, parts.hostname, port, path)
        except ValueError as exc:
            if isinstance(exc, ParseError):
                raise
            raise ParseError(f"Некорректный URL: {exc}") from exc


@dataclass
class Request:
    method: str
    path: str
    version: str = "HTTP/1.1"
    headers: Dict[str, str] = field(default_factory=dict)
    body: bytes = b""


@dataclass
class Response:
    status: int
    reason: str = ""
    version: str = "HTTP/1.1"
    headers: Dict[str, str] = field(default_factory=dict)
    body: bytes = b""
