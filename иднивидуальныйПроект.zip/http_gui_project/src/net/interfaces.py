from abc import ABC, abstractmethod
from .socket_wrapper import SocketWrapper

class IHttpClient(ABC):
    @abstractmethod
    def get(self, url, headers=None): ...
    @abstractmethod
    def post(self, url, body, content_type="text/plain", headers=None): ...

class IHttpServer(ABC):
    @abstractmethod
    def start(self, host="127.0.0.1", port=8080): ...
    @abstractmethod
    def stop(self): ...
