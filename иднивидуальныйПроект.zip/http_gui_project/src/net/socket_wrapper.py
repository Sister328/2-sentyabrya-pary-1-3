import socket

class SocketWrapper:
    """Small RAII-style socket wrapper."""
    def __init__(self, sock): self._sock = sock
    def __enter__(self): return self
    def __exit__(self, exc_type, exc, tb): self.close()
    def close(self):
        if self._sock is not None:
            try: self._sock.shutdown(socket.SHUT_RDWR)
            except OSError: pass
            self._sock.close(); self._sock = None
    def send_all(self, data): self._sock.sendall(data)
    def recv(self, size): return self._sock.recv(size)
    @property
    def raw(self): return self._sock
