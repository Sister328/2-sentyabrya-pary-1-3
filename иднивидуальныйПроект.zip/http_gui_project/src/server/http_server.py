import logging, socket, threading, time
from ..http.codec import parse_request, serialize_response
from ..http.models import Response, ParseError
from ..net.interfaces import IHttpServer

log = logging.getLogger(__name__)

class HttpServer(IHttpServer):
    def __init__(self, router, log_callback=None):
        self.router = router; self.log_callback = log_callback or (lambda item: None)
        self._sock = None; self._thread = None; self._stop = threading.Event(); self.port = 8080
    @property
    def running(self): return self._thread is not None and self._thread.is_alive() and not self._stop.is_set()
    def start(self, host="127.0.0.1", port=8080):
        if not 1 <= int(port) <= 65535: raise ValueError("Порт должен быть в диапазоне 1–65535.")
        if self.running: raise RuntimeError("Сервер уже запущен.")
        self.port = int(port); self._stop.clear()
        self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._sock.bind((host, self.port)); self._sock.listen(64); self._sock.settimeout(0.3)
        self._thread = threading.Thread(target=self._serve, name="http-accept", daemon=True); self._thread.start()
    def stop(self):
        self._stop.set()
        if self._sock:
            try: self._sock.close()
            except OSError: pass
        if self._thread and self._thread is not threading.current_thread(): self._thread.join(timeout=2)
        self._sock = None
    def _serve(self):
        while not self._stop.is_set():
            try: conn, addr = self._sock.accept()
            except socket.timeout: continue
            except OSError:
                if self._stop.is_set(): break
                log.exception("Ошибка accept"); continue
            threading.Thread(target=self._handle, args=(conn, addr), daemon=True).start()
    def _handle(self, conn, addr):
        # One TCP connection may carry multiple HTTP/1.1 requests (keep-alive).
        buffer = bytearray()
        try:
            conn.settimeout(3)
            with conn:
                while not self._stop.is_set():
                    started = time.perf_counter(); method = path = "?"; status = 400
                    try:
                        while b"\r\n\r\n" not in buffer:
                            part = conn.recv(4096)
                            if not part:
                                return
                            buffer.extend(part)
                            if len(buffer) > 8192:
                                raise ParseError("HTTP-заголовки слишком велики")
                        head, _, remaining = bytes(buffer).partition(b"\r\n\r\n")
                        header_text = head.decode("iso-8859-1")
                        content_length = 0
                        for line in header_text.split("\r\n")[1:]:
                            if line.lower().startswith("content-length:"):
                                try: content_length = int(line.split(":", 1)[1].strip())
                                except ValueError as exc: raise ParseError("Некорректный Content-Length") from exc
                        if content_length < 0 or content_length > 8 * 1024 * 1024:
                            raise ParseError("Недопустимый размер тела")
                        buffer = bytearray(remaining)
                        while len(buffer) < content_length:
                            part = conn.recv(min(4096, content_length - len(buffer)))
                            if not part: raise ParseError("Тело запроса неполное")
                            buffer.extend(part)
                        body = bytes(buffer[:content_length])
                        buffer = bytearray(buffer[content_length:])
                        req = parse_request(head + b"\r\n\r\n" + body)
                        method, path = req.method, req.path
                        req_headers = {k.lower(): v.lower() for k, v in req.headers.items()}
                        keep_alive = req_headers.get("connection", "") != "close" if req.version == "HTTP/1.1" else req_headers.get("connection", "") == "keep-alive"
                        if method not in ("GET", "POST"):
                            resp = Response(405, "Method Not Allowed", body=b"405 Method Not Allowed", headers={"Content-Type":"text/plain; charset=utf-8"})
                        else:
                            resp = self.router.dispatch(req)
                        status = resp.status
                        resp.headers["Connection"] = "keep-alive" if keep_alive else "close"
                        conn.sendall(serialize_response(resp))
                        item = {"time":time.strftime("%H:%M:%S"), "method":method, "path":path, "status":status, "ms":round((time.perf_counter()-started)*1000, 2)}
                        log.info("%s %s %s %sms", method, path, status, item["ms"])
                        self.log_callback(item)
                        if not keep_alive:
                            return
                    except (ParseError, ValueError, ConnectionError, OSError, socket.timeout) as exc:
                        log.debug("Request from %s failed: %s", addr, exc)
                        try: conn.sendall(serialize_response(Response(400, "Bad Request", body=b"400 Bad Request", headers={"Content-Type":"text/plain", "Connection":"close"})))
                        except OSError: pass
                        return
        except OSError:
            log.debug("Connection from %s closed", addr)

