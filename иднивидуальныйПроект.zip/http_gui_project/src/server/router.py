import json
from datetime import datetime, timezone
from ..http.models import Request, Response

class Router:
    def __init__(self): self._routes = {}
    def route(self, method, path, handler): self._routes[(method.upper(), path)] = handler
    def dispatch(self, req: Request) -> Response:
        path = req.path.split("?", 1)[0]
        handler = self._routes.get((req.method.upper(), path))
        if handler: return handler(req)
        if path.startswith("/status/") and req.method.upper() == "GET":
            try:
                code = int(path.rsplit("/", 1)[1])
                if not 100 <= code <= 599: raise ValueError
                return Response(code, body=f"HTTP status {code}".encode(), headers={"Content-Type":"text/plain; charset=utf-8"})
            except ValueError: return Response(400, body=b"Invalid status code")
        return Response(404, "Not Found", body=b"404 Not Found", headers={"Content-Type":"text/plain; charset=utf-8"})

def build_router():
    router = Router()
    router.route("GET", "/", lambda req: Response(200, body=b"<!doctype html><html><head><meta charset='utf-8'><title>Hello</title></head><body><h1>Hello</h1><p>Educational HTTP server is running.</p></body></html>", headers={"Content-Type":"text/html; charset=utf-8"}))
    def echo(req):
        ct = next((v for k,v in req.headers.items() if k.lower()=="content-type"), "application/octet-stream")
        return Response(200, body=req.body, headers={"Content-Type":ct})
    router.route("POST", "/echo", echo)
    router.route("GET", "/time", lambda req: Response(200, body=json.dumps({"time":datetime.now(timezone.utc).isoformat()}, ensure_ascii=False).encode(), headers={"Content-Type":"application/json; charset=utf-8"}))
    router.route("GET", "/headers", lambda req: Response(200, body=json.dumps(req.headers, ensure_ascii=False, indent=2).encode(), headers={"Content-Type":"application/json; charset=utf-8"}))
    return router
