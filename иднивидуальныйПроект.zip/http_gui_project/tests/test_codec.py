import unittest
from src.http.codec import parse_request, serialize_request, serialize_response
from src.http.models import Request, Response, ParseError

class CodecTests(unittest.TestCase):
    def test_parse_get(self):
        r=parse_request(b'GET / HTTP/1.1\r\nHost: localhost\r\n\r\n'); self.assertEqual(r.method,'GET'); self.assertEqual(r.path,'/')
    def test_parse_body(self):
        r=parse_request(b'POST /echo HTTP/1.1\r\nHost: localhost\r\nContent-Length: 3\r\n\r\nabc'); self.assertEqual(r.body,b'abc')
    def test_missing_host(self):
        with self.assertRaises(ParseError): parse_request(b'GET / HTTP/1.1\r\n\r\n')
    def test_bad_start_line(self):
        with self.assertRaises(ParseError): parse_request(b'GARBAGE\r\n\r\n')
    def test_header_limit(self):
        with self.assertRaises(ParseError): parse_request(b'GET / HTTP/1.1\r\nHost: x\r\nX: '+b'a'*9000+b'\r\n\r\n')
    def test_serialize_request(self):
        data=serialize_request(Request('GET','/')); self.assertIn(b'\r\n\r\n',data); self.assertIn(b'Host:',data)
    def test_serialize_response_length(self):
        data=serialize_response(Response(200,body=b'abc')); self.assertIn(b'Content-Length: 3',data)
    def test_content_length_invalid(self):
        with self.assertRaises(ParseError): parse_request(b'POST / HTTP/1.1\r\nHost: x\r\nContent-Length: nope\r\n\r\nx')
    def test_negative_content_length(self):
        with self.assertRaises(ParseError): parse_request(b'POST / HTTP/1.1\r\nHost: x\r\nContent-Length: -1\r\n\r\n')
    def test_body_truncated(self):
        with self.assertRaises(ParseError): parse_request(b'POST / HTTP/1.1\r\nHost: x\r\nContent-Length: 3\r\n\r\na')
    def test_response_status_reason(self):
        data=serialize_response(Response(418, body=b'tea')); self.assertIn(b"418 I'm a teapot",data)
    def test_response_date(self):
        data=serialize_response(Response(200, body=b'')); self.assertIn(b'Date:',data)
    def test_response_empty_content_length(self):
        data=serialize_response(Response(204, body=b'')); self.assertIn(b'Content-Length: 0',data)

if __name__=='__main__': unittest.main()
