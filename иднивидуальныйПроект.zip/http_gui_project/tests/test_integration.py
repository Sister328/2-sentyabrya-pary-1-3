import socket, threading, time, unittest
from src.client.http_client import HttpClient
from src.server.http_server import HttpServer
from src.server.router import build_router

class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        s=socket.socket(); s.bind(('127.0.0.1',0)); cls.port=s.getsockname()[1]; s.close()
        cls.server=HttpServer(build_router()); cls.server.start(port=cls.port)
        cls.client=HttpClient(2000); time.sleep(.1)
    @classmethod
    def tearDownClass(cls): cls.server.stop()
    def url(self,path='/'): return f'http://127.0.0.1:{self.port}{path}'
    def test_root(self):
        r=self.client.get(self.url()); self.assertEqual(r.status,200); self.assertIn(b'Hello',r.body)
    def test_echo(self):
        r=self.client.post(self.url('/echo'),'hello','text/plain'); self.assertEqual(r.status,200); self.assertEqual(r.body,b'hello'); self.assertEqual(r.headers.get('Content-Type'),'text/plain')
    def test_status_route(self): self.assertEqual(self.client.get(self.url('/status/418')).status,418)
    def test_unknown_route(self): self.assertEqual(self.client.get(self.url('/missing')).status,404)
    def test_time_json(self): self.assertIn(b'time',self.client.get(self.url('/time')).body)
    def test_headers(self): self.assertEqual(self.client.get(self.url('/headers')).status,200)
    def test_sequential_requests(self):
        for _ in range(20): self.assertEqual(self.client.get(self.url()).status,200)
    def test_keep_alive_three_requests(self):
        sock=socket.create_connection(("127.0.0.1", self.port), timeout=2)
        try:
            for path in ("/", "/time", "/status/418"):
                sock.sendall(f"GET {path} HTTP/1.1\r\nHost: localhost\r\nConnection: keep-alive\r\n\r\n".encode())
                data=bytearray()
                while b"\r\n\r\n" not in data: data.extend(sock.recv(4096))
                head, _, body=bytes(data).partition(b"\r\n\r\n")
                headers={}
                for line in head.decode("iso-8859-1").split("\r\n")[1:]:
                    if ":" in line:
                        k,v=line.split(":",1); headers[k.lower()]=v.strip()
                length=int(headers.get("content-length", "0"))
                while len(body)<length: body += sock.recv(4096)
                self.assertIn(b"HTTP/1.1",head)
                self.assertEqual(headers.get("connection"),"keep-alive")
            sock.sendall(b"GET / HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n")
        finally: sock.close()
    def test_parallel_requests(self):
        statuses=[]; lock=threading.Lock()
        def run():
            status=self.client.get(self.url()).status
            with lock: statuses.append(status)
        threads=[threading.Thread(target=run) for _ in range(10)]
        [t.start() for t in threads]; [t.join() for t in threads]
        self.assertEqual(statuses,[200]*10)

if __name__=='__main__': unittest.main()
