import unittest
from src.http.models import Url, ParseError

class UrlTests(unittest.TestCase):
    def test_url_with_query(self):
        u=Url.parse('http://host:8080/path?q=1'); self.assertEqual((u.host,u.port,u.path),('host',8080,'/path?q=1'))
    def test_default_port(self): self.assertEqual(Url.parse('http://host/path').port,80)
    def test_https_default_port(self): self.assertEqual(Url.parse('https://host/').port,443)
    def test_bad_url(self):
        with self.assertRaises(ParseError): Url.parse('garbage')
    def test_bad_scheme(self):
        with self.assertRaises(ParseError): Url.parse('ftp://host/file')
    def test_bad_port(self):
        with self.assertRaises(ParseError): Url.parse('http://host:99999/')
    def test_empty_url(self):
        with self.assertRaises(ParseError): Url.parse('')
    def test_path_default(self): self.assertEqual(Url.parse('http://host').path, '/')
    def test_query_only(self): self.assertEqual(Url.parse('http://host?q=x').path, '/?q=x')
    def test_https_scheme(self): self.assertEqual(Url.parse('https://host').scheme, 'https')
    def test_ipv4_port(self): self.assertEqual(Url.parse('http://127.0.0.1:9000/').port, 9000)

if __name__=='__main__': unittest.main()
